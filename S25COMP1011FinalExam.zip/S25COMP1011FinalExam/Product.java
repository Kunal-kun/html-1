package YOUR_PACKAGE_NAME;

public class Product {
  }
